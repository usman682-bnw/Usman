"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ExternalLinkIcon, GithubIcon, CodeIcon } from "lucide-react"

const projects = [
  {
    id: 1,
    title: "E-Commerce Platform",
    description:
      "A fully responsive e-commerce platform with product filtering, cart functionality, and payment integration.",
    image: "/placeholder.svg?height=600&width=800",
    category: "web",
    technologies: ["React", "Next.js", "Tailwind CSS", "Stripe"],
    demoLink: "#",
    githubLink: "#",
  },
  {
    id: 2,
    title: "Task Management App",
    description: "A drag-and-drop task management application with user authentication and real-time updates.",
    image: "/placeholder.svg?height=600&width=800",
    category: "web",
    technologies: ["Vue.js", "Firebase", "Tailwind CSS"],
    demoLink: "#",
    githubLink: "#",
  },
  {
    id: 3,
    title: "Portfolio Website",
    description: "A modern portfolio website with smooth animations and dark mode support.",
    image: "/placeholder.svg?height=600&width=800",
    category: "web",
    technologies: ["React", "Framer Motion", "Tailwind CSS"],
    demoLink: "#",
    githubLink: "#",
  },
  {
    id: 4,
    title: "Weather Dashboard",
    description: "A weather dashboard that displays current and forecasted weather data for any location.",
    image: "/placeholder.svg?height=600&width=800",
    category: "app",
    technologies: ["JavaScript", "OpenWeather API", "Chart.js"],
    demoLink: "#",
    githubLink: "#",
  },
  {
    id: 5,
    title: "Recipe Finder",
    description: "A recipe finder application that allows users to search for recipes based on ingredients.",
    image: "/placeholder.svg?height=600&width=800",
    category: "app",
    technologies: ["React", "Spoonacular API", "CSS Modules"],
    demoLink: "#",
    githubLink: "#",
  },
  {
    id: 6,
    title: "Corporate Website",
    description: "A corporate website with multiple pages, contact form, and blog functionality.",
    image: "/placeholder.svg?height=600&width=800",
    category: "design",
    technologies: ["WordPress", "Custom Theme", "PHP", "SCSS"],
    demoLink: "#",
    githubLink: "#",
  },
]

export default function Projects() {
  const [activeTab, setActiveTab] = useState("all")
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  const filteredProjects = activeTab === "all" ? projects : projects.filter((project) => project.category === activeTab)

  return (
    <section id="projects" className="py-20">
      <div className="container px-4">
        <motion.div
          ref={ref}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          variants={containerVariants}
          className="max-w-6xl mx-auto"
        >
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">My Projects</h2>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-foreground/70 max-w-2xl mx-auto">
              Explore my recent projects and see how I bring ideas to life with code and creativity.
            </p>
          </motion.div>

          <motion.div variants={itemVariants} className="mb-12">
            <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
              <TabsList className="mx-auto mb-8">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="web">Web</TabsTrigger>
                <TabsTrigger value="app">Apps</TabsTrigger>
                <TabsTrigger value="design">Design</TabsTrigger>
              </TabsList>

              <TabsContent value={activeTab} className="mt-0">
                <motion.div
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
                >
                  {filteredProjects.map((project) => (
                    <motion.div key={project.id} variants={itemVariants}>
                      <ProjectCard project={project} />
                    </motion.div>
                  ))}
                </motion.div>
              </TabsContent>
            </Tabs>
          </motion.div>

          <motion.div variants={itemVariants} className="text-center">
            <Button size="lg" variant="outline" className="rounded-full px-8">
              View All Projects
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

function ProjectCard({ project }) {
  return (
    <Card className="overflow-hidden group border border-border/50 hover:border-primary/50 transition-all duration-300 h-full flex flex-col">
      <div className="relative overflow-hidden">
        <Image
          src={project.image || "/placeholder.svg"}
          alt={project.title}
          width={800}
          height={600}
          className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-4">
          <Button size="icon" variant="secondary" asChild>
            <a href={project.demoLink} target="_blank" rel="noopener noreferrer" aria-label="View demo">
              <ExternalLinkIcon className="h-5 w-5" />
            </a>
          </Button>
          <Button size="icon" variant="secondary" asChild>
            <a href={project.githubLink} target="_blank" rel="noopener noreferrer" aria-label="View code on GitHub">
              <GithubIcon className="h-5 w-5" />
            </a>
          </Button>
        </div>
      </div>
      <CardContent className="p-6 flex-1 flex flex-col">
        <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">{project.title}</h3>
        <p className="text-foreground/70 mb-4 flex-1">{project.description}</p>
        <div className="flex flex-wrap gap-2 mt-auto">
          {project.technologies.map((tech, index) => (
            <div
              key={index}
              className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary flex items-center gap-1"
            >
              <CodeIcon className="h-3 w-3" />
              {tech}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

