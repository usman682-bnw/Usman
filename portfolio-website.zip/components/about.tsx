"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { BriefcaseIcon, GraduationCapIcon, AwardIcon } from "lucide-react"

export default function About() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="about" className="py-20 bg-muted/30">
      <div className="container px-4">
        <motion.div
          ref={ref}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          variants={containerVariants}
          className="max-w-5xl mx-auto"
        >
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">About Me</h2>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-foreground/70 max-w-2xl mx-auto">
              Get to know more about me, my background, and what drives me as a developer.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div variants={itemVariants} className="relative">
              <div className="relative z-10 rounded-lg overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=600&width=500"
                  alt="Profile"
                  width={500}
                  height={600}
                  className="w-full h-auto object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 w-full h-full border-4 border-primary rounded-lg -z-10"></div>
            </motion.div>

            <motion.div variants={itemVariants}>
              <h3 className="text-2xl font-bold mb-4">Front-end Developer & UI/UX Enthusiast</h3>
              <p className="text-foreground/70 mb-6">
                I'm a passionate front-end developer with a keen eye for design and a commitment to creating intuitive,
                responsive web applications. With a strong foundation in HTML, CSS, and JavaScript, I specialize in
                building modern web experiences that are both functional and visually appealing.
              </p>
              <p className="text-foreground/70 mb-6">
                My journey in web development began 5 years ago, and since then, I've worked on a variety of projects
                that have allowed me to refine my skills and stay current with the latest technologies and best
                practices in the field.
              </p>

              <div className="grid grid-cols-2 gap-4 mb-8">
                <div>
                  <h4 className="font-semibold mb-2">Name:</h4>
                  <p className="text-foreground/70">Your Name</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Email:</h4>
                  <p className="text-foreground/70">your.email@example.com</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Location:</h4>
                  <p className="text-foreground/70">City, Country</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Availability:</h4>
                  <p className="text-foreground/70">Available for hire</p>
                </div>
              </div>

              <Button size="lg" className="rounded-full px-8">
                Download CV
              </Button>
            </motion.div>
          </div>

          <motion.div variants={itemVariants} className="grid md:grid-cols-3 gap-6 mt-16">
            <Card className="bg-background/50 backdrop-blur-sm border border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-md">
              <CardContent className="p-6">
                <div className="mb-4 text-primary">
                  <BriefcaseIcon className="h-10 w-10" />
                </div>
                <h3 className="text-xl font-bold mb-2">Experience</h3>
                <p className="text-foreground/70">
                  5+ years of professional experience in front-end development, working with modern frameworks and
                  libraries.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-background/50 backdrop-blur-sm border border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-md">
              <CardContent className="p-6">
                <div className="mb-4 text-primary">
                  <GraduationCapIcon className="h-10 w-10" />
                </div>
                <h3 className="text-xl font-bold mb-2">Education</h3>
                <p className="text-foreground/70">
                  Bachelor's degree in Computer Science with a focus on web technologies and user experience design.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-background/50 backdrop-blur-sm border border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-md">
              <CardContent className="p-6">
                <div className="mb-4 text-primary">
                  <AwardIcon className="h-10 w-10" />
                </div>
                <h3 className="text-xl font-bold mb-2">Achievements</h3>
                <p className="text-foreground/70">
                  Recognized for outstanding web development projects and contributions to open-source communities.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

