"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { GithubIcon, LinkedinIcon, TwitterIcon, InstagramIcon, ArrowUpIcon } from "lucide-react"

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    })
  }

  return (
    <footer className="bg-muted/50 py-12">
      <div className="container px-4">
        <div className="flex flex-col items-center">
          <Button
            variant="outline"
            size="icon"
            className="rounded-full mb-8"
            onClick={scrollToTop}
            aria-label="Scroll to top"
          >
            <ArrowUpIcon className="h-5 w-5" />
          </Button>

          <Link
            href="#home"
            className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent mb-6"
          >
            Dev<span className="text-primary">Portfolio</span>
          </Link>

          <div className="flex gap-4 mb-8">
            <Button variant="ghost" size="icon" className="rounded-full" aria-label="GitHub">
              <GithubIcon className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full" aria-label="LinkedIn">
              <LinkedinIcon className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full" aria-label="Twitter">
              <TwitterIcon className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full" aria-label="Instagram">
              <InstagramIcon className="h-5 w-5" />
            </Button>
          </div>

          <div className="flex flex-wrap justify-center gap-6 mb-8">
            <Link href="#home" className="text-foreground/70 hover:text-primary transition-colors">
              Home
            </Link>
            <Link href="#about" className="text-foreground/70 hover:text-primary transition-colors">
              About
            </Link>
            <Link href="#projects" className="text-foreground/70 hover:text-primary transition-colors">
              Projects
            </Link>
            <Link href="#skills" className="text-foreground/70 hover:text-primary transition-colors">
              Skills
            </Link>
            <Link href="#contact" className="text-foreground/70 hover:text-primary transition-colors">
              Contact
            </Link>
          </div>

          <div className="text-center text-foreground/60 text-sm">
            <p>© {new Date().getFullYear()} Your Name. All rights reserved.</p>
            <p className="mt-1">Designed and built with ❤️</p>
          </div>
        </div>
      </div>
    </footer>
  )
}

