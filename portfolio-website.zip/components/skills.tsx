"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const frontendSkills = [
  { name: "HTML5", level: 95 },
  { name: "CSS3/SCSS", level: 90 },
  { name: "JavaScript", level: 85 },
  { name: "TypeScript", level: 80 },
  { name: "React", level: 85 },
  { name: "Next.js", level: 80 },
  { name: "Tailwind CSS", level: 90 },
  { name: "Framer Motion", level: 75 },
]

const backendSkills = [
  { name: "Node.js", level: 70 },
  { name: "Express", level: 65 },
  { name: "MongoDB", level: 60 },
  { name: "Firebase", level: 75 },
  { name: "REST API", level: 80 },
  { name: "GraphQL", level: 60 },
]

const designSkills = [
  { name: "Figma", level: 85 },
  { name: "Adobe XD", level: 75 },
  { name: "UI/UX Design", level: 80 },
  { name: "Responsive Design", level: 90 },
  { name: "Wireframing", level: 85 },
  { name: "Prototyping", level: 80 },
]

const otherSkills = [
  { name: "Git/GitHub", level: 85 },
  { name: "Webpack", level: 70 },
  { name: "Jest", level: 65 },
  { name: "CI/CD", level: 60 },
  { name: "Performance Optimization", level: 75 },
  { name: "SEO", level: 70 },
]

export default function Skills() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="skills" className="py-20 bg-muted/30">
      <div className="container px-4">
        <motion.div
          ref={ref}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          variants={containerVariants}
          className="max-w-6xl mx-auto"
        >
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">My Skills</h2>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-foreground/70 max-w-2xl mx-auto">
              Here are the technologies and tools I work with to bring ideas to life.
            </p>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Tabs defaultValue="frontend" className="w-full">
              <TabsList className="mx-auto mb-8 grid w-full max-w-md grid-cols-4">
                <TabsTrigger value="frontend">Frontend</TabsTrigger>
                <TabsTrigger value="backend">Backend</TabsTrigger>
                <TabsTrigger value="design">Design</TabsTrigger>
                <TabsTrigger value="other">Other</TabsTrigger>
              </TabsList>

              <TabsContent value="frontend">
                <SkillsGrid skills={frontendSkills} />
              </TabsContent>

              <TabsContent value="backend">
                <SkillsGrid skills={backendSkills} />
              </TabsContent>

              <TabsContent value="design">
                <SkillsGrid skills={designSkills} />
              </TabsContent>

              <TabsContent value="other">
                <SkillsGrid skills={otherSkills} />
              </TabsContent>
            </Tabs>
          </motion.div>

          <motion.div variants={itemVariants} className="grid md:grid-cols-4 gap-6 mt-16">
            <SkillCard
              title="Frontend Development"
              description="Building responsive, accessible, and performant user interfaces with modern frameworks and libraries."
              icon="🖥️"
            />
            <SkillCard
              title="Backend Integration"
              description="Connecting frontend applications with backend services and APIs to create full-stack solutions."
              icon="⚙️"
            />
            <SkillCard
              title="UI/UX Design"
              description="Creating intuitive and visually appealing user experiences that delight and engage users."
              icon="🎨"
            />
            <SkillCard
              title="Performance Optimization"
              description="Optimizing web applications for speed, accessibility, and search engine visibility."
              icon="⚡"
            />
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

function SkillsGrid({ skills }) {
  return (
    <div className="grid md:grid-cols-2 gap-8">
      {skills.map((skill, index) => (
        <motion.div
          key={skill.name}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1, duration: 0.5 }}
        >
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-medium">{skill.name}</h3>
              <span className="text-sm text-primary">{skill.level}%</span>
            </div>
            <Progress value={skill.level} className="h-2" />
          </div>
        </motion.div>
      ))}
    </div>
  )
}

function SkillCard({ title, description, icon }) {
  return (
    <Card className="bg-background/50 backdrop-blur-sm border border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-md">
      <CardContent className="p-6">
        <div className="text-4xl mb-4">{icon}</div>
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <p className="text-foreground/70">{description}</p>
      </CardContent>
    </Card>
  )
}

